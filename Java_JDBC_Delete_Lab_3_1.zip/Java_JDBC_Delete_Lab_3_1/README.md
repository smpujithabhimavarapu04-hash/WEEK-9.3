# JDBC Delete Data — Lab 3.1

## Aim
Connect to a MySQL database using JDBC and delete the record from the `users` table whose `id` is `2`, using a `PreparedStatement`.

## Requirements
- Java JDK
- MySQL Server
- MySQL Connector/J driver
- Database named `mydatabase`
- Table `users` with an `id` column

## 1. Prepare the database
Run this in MySQL if the database does not already exist:

```sql
CREATE DATABASE IF NOT EXISTS mydatabase;
USE mydatabase;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(200)
);

-- Optional sample row for testing:
INSERT INTO users (id, name, email)
VALUES (2, 'John Doe', 'john.doe@example.com');
```

If your existing `users` table uses `AUTO_INCREMENT` for `id`, that is fine too. If row `id = 2` already exists, avoid inserting the sample row again.

## 2. Configure your password
Open `JDBCDeleteDemo.java` and replace `your_password` with your local MySQL password. Do not commit a real password to a public GitHub repository.

## 3. Add MySQL Connector/J
Download/use the MySQL Connector/J JAR and put its path on the classpath.

### macOS / Linux
```bash
javac -cp ".:/path/to/mysql-connector-j.jar" JDBCDeleteDemo.java
java -cp ".:/path/to/mysql-connector-j.jar" JDBCDeleteDemo
```

### Windows
```bat
javac -cp ".;C:\path\to\mysql-connector-j.jar" JDBCDeleteDemo.java
java -cp ".;C:\path\to\mysql-connector-j.jar" JDBCDeleteDemo
```

Replace the example JAR path with the actual location of your Connector/J file.

## Expected output
If user ID 2 exists:
```text
Row deleted successfully.
```

If user ID 2 does not exist:
```text
No rows were deleted.
```

## How it works
1. Opens a JDBC connection to `mydatabase`.
2. Prepares `DELETE FROM users WHERE id = ?`.
3. Sets the parameter to `2`.
4. Calls `executeUpdate()` and checks the number of rows affected.
5. Prints the appropriate message and handles any `SQLException`.

**Note:** Running the program deletes the row with ID 2. Use test data if you do not want to remove a real record.
