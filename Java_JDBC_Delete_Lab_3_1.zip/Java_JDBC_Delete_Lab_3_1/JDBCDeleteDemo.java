import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCDeleteDemo {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USERNAME = "root";

    // Replace this placeholder with your own MySQL password.
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        String deleteSql = "DELETE FROM users WHERE id = ?";

        try (Connection connection =
                     DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement =
                     connection.prepareStatement(deleteSql)) {

            preparedStatement.setInt(1, 2); // User ID to delete
            int rowsDeleted = preparedStatement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Row deleted successfully.");
            } else {
                System.out.println("No rows were deleted.");
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            System.err.println(
                    "Check that MySQL is running, database 'mydatabase' and table "
                    + "'users' exist, credentials are correct, and MySQL Connector/J "
                    + "is in the classpath."
            );
        }
    }
}
